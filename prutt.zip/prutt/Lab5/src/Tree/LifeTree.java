package Tree;

public class LifeTree {

}
