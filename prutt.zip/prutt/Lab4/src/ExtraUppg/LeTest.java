package ExtraUppg;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Queue;

import Uppg1.Component;

public class LeTest {
//testa med arraylist
	public static void main (String[] args) {
		ArrayList<String> stuff = new ArrayList<String>();
		stuff.add("Jeans");
		stuff.add("Jumper");
		stuff.add("Socks");
		stuff.add("Beretta");
		//Backpack
		stuff.add("Pokeballs");
		stuff.add("Homework");
		//Vanity bag
		stuff.add("Shampoo");
		stuff.add("Soap");
		stuff.add("Lipstick");
		stuff.add("Happy pills");
	}
	
	
}
