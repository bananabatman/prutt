package ExtraUppg;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Stack;

import Uppg1.Component;
import Uppg1.Composite;

public class Djupet implements Iterator {
	//Behöver en stack
	private Stack<Component> bStack;
	private ArrayList<Component> inList;
	private Stack<Component> bfs_s;
	private Component parent;
	//Ha koll på hur långt man gått med next

	public Djupet(ArrayList<Component> inList) {
		System.out.println("start");
		bStack = new Stack<Component>();
		this.inList=inList;
		bStack.addAll(this.inList);
		bfs_s = fill(parent);
	}

	//Låt Composite implementera Iterable så att den har metoden iterator()
	//Definiera iterator() så att den returnerar ett iterator objekt
	//gå igenom composite med for each sats såväl som iteratorns metoder

	//Besök först roten, därefter rotens alla barn, sen rotens barnbarn osv.
	
	public boolean hasNext() {
		//Använd peek och titta om det fungerar
		// returnera true om det finns fler element att besöka
		
		if(bfs_s.isEmpty()){
			return false;
		}
		else{
			return true;
		}
	}
	
	private Stack<Component> fill (Component parent) {
		Stack<Component> output = new Stack<Component>();
		while(!bStack.isEmpty()) {
			if(bStack.peek().getClass().equals(Uppg1.Composite.class)) {
				parent = bStack.pop();
				output.add(parent);
				Composite compP = (Composite) parent;
				bStack.addAll(compP.compList);
				if(bStack.peek().getClass().equals(Uppg1.Leaf.class)) {
					output.add(bStack.pop());
				} else {
					parent = bStack.pop();
					fill(parent);
				}
			}
			else{
				output.add(bStack.pop());
			}
		}
		
		// Object.getClass(); för att kolla om löv eller träd
		// gå fram ett steg enligt bredden först 
		// och stoppa element i kön
		return output;
	}

	public Component next() {
		//element fungerar som peek men throws exception
		//om nästa element är null
		if(hasNext()){
			return bfs_s.pop();
		}else{
			return null;
		}
		
	}

	public void remove() {
		//NEJ
		// krävs ej i labben, implementeras tom
	}

}
