package Uppg1;

import java.util.ArrayList;
import java.util.Scanner;

public class Test {

		//OBS TÄNK REEKURSIVT
	public static void main (String[] args) {
		ArrayList<String> stuff = new ArrayList<String>();
		ArrayList<String> bags = new ArrayList<String>();
		ArrayList<Leaf> stuffComp = new ArrayList<Leaf>();
		ArrayList<Composite> bagComp = new ArrayList<Composite>();
		bags.add("Suitcase");
		bags.add("Backpack");
		bags.add("Vanity bag");

		for(int i=0; i<bags.size(); i++) {
			Composite root = new Composite(bags.get(i), 4-i);
			bagComp.add(root);
		}
		
		//Suitcase
		stuff.add("Jeans");
		stuff.add("Jumper");
		stuff.add("Socks");
		stuff.add("Beretta");
		//Backpack
		stuff.add("Pokeballs");
		stuff.add("Homework");
		//Vanity bag
		stuff.add("Shampoo");
		stuff.add("Soap");
		stuff.add("Lipstick");
		stuff.add("Happy pills");
		
		for(int i=0; i<stuff.size(); i++) {
			Leaf leaf = new Leaf(stuff.get(i), i);
			stuffComp.add(leaf);
		}
		
		for(int i=0;i<stuffComp.size(); i++){
			System.out.println(stuffComp.get(i).toString());
		}
		for(int i=0;i<bagComp.size(); i++){
			System.out.println(bagComp.get(i).toString());
		}
		
		for(int i=0;i<stuffComp.size();i++){
			if(i<4){
				bagComp.get(0).add(stuffComp.get(i));
			}else if((i >= 4) && (i<6)){
				bagComp.get(1).add(stuffComp.get(i));
				
			}else {
				bagComp.get(2).add(stuffComp.get(i));
			}
		}
		for(int i=0;i<bagComp.size(); i++){
			System.out.println(bagComp.get(i).toString()+" "+bagComp.get(i).getWeight());
		}
		System.out.println(" --- filling bags --- ");
		bagComp.get(0).add(bagComp.get(1));
		bagComp.get(1).add(bagComp.get(2));
		for(int i=0;i<bagComp.size(); i++){
			System.out.println(bagComp.get(i).toString()+" "+bagComp.get(i).getWeight());
		}
		System.out.println(" --- Removing objects --- ");
		bagComp.get(0).remove(stuffComp.get(1));
		bagComp.get(1).remove(stuffComp.get(4));
		bagComp.get(2).remove(stuffComp.get(7));
		
		for(int i=0;i<bagComp.size(); i++){
			System.out.println(bagComp.get(i).toString()+" "+bagComp.get(i).getWeight());
		}
	}
	
	//Note to self: vad skiljer interface <-> abstract class?
	//Implementeringstvång enbart? (antagligen inte)
	//Vad är ett objektdiagram?

}
